// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.threed.jpct;

import java.awt.Component;

class DummyCanvas extends Component {

	DummyCanvas() {
	}

	private static final long serialVersionUID = 1L;
}

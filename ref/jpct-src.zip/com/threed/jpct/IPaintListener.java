// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: packimports(3) 

package com.threed.jpct;

import java.io.Serializable;

public interface IPaintListener extends Serializable {

	public abstract void startPainting();

	public abstract void finishedPainting();
}
